type Product = {
  // egészítse ki (id, name, price megnevezésekkel és tipusokkal)  

};

/*
* Ide hozza létre a createProduct(), coinFlips(), countEvenNumbers függvényeket.
*   
*/


/*********** Tesztek *******************/
const taskResults = document.getElementById("task-results")!;
const testResults = document.getElementById("test-results")!;
let testCounter = 1;

function addTaskOutput(text: string) {
  const li = document.createElement("li");
  li.textContent = text;
  taskResults.appendChild(li);
}

function addTestResult(desc: string, passed: boolean) {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>${testCounter++}</td>
    <td>${desc}</td>
    <td class="${passed ? "success" : "fail"}">${passed ? "✅ OK" : "❌ HIBA"}</td>
  `;
  testResults.appendChild(tr);
}

// Kiírás (védetten)
try {
  const createProductFn = (window as any)["createProduct"];
  if (typeof createProductFn === "function") {
    addTaskOutput("Product: " + JSON.stringify(createProductFn()));
  } else {
    throw new Error("createProduct nincs definiálva");
  }
} catch (e) {
  addTaskOutput("Product: ❌ createProduct() nem működik");
}

try {
  const coinFlipsFn = (window as any)["coinFlips"];
  if (typeof coinFlipsFn === "function") {
    addTaskOutput("Coin flips (5): " + coinFlipsFn(5).join(", "));
  } else {
    throw new Error("coinFlips nincs definiálva");
  }
} catch (e) {
  addTaskOutput("Coin flips: ❌ coinFlips() nem működik");
}

try {
  const countEvenFn = (window as any)["countEvenNumbers"];
  if (typeof countEvenFn === "function") {
    addTaskOutput("Even count: " + countEvenFn([1, 2, 4, 5, 8, 11]));
  } else {
    throw new Error("countEvenNumbers nincs definiálva");
  }
} catch (e) {
  addTaskOutput("Even count: ❌ countEvenNumbers() nem működik");
}

// Tesztek (védetten)
try {
  const createProductFn = (window as any)["createProduct"];
  addTestResult("createProduct() definiálva van", typeof createProductFn === "function");
  const product = createProductFn();
  addTestResult("Product id szám", typeof product.id === "number");
  addTestResult("Product name szöveg", typeof product.name === "string");
  addTestResult("Product price szám", typeof product.price === "number");
  addTestResult("Product name tartalma tesztnév", product.name === "tesztnév");
} catch (err) {
  addTestResult("createProduct() működése hibás vagy nincs definiálva", false);
}

try {
  const coinFlipsFn = (window as any)["coinFlips"];
  addTestResult("coinFlips() definiálva van", typeof coinFlipsFn === "function");
  const flips = coinFlipsFn(10);
  addTestResult("CoinFlips tömbbel tér vissza", Array.isArray(flips));
  addTestResult("CoinFlips hossza 10", flips.length === 10);
  addTestResult("CoinFlips értékei érvényesek", flips.every(f => f === "fej" || f === "írás"));
} catch (err) {
  addTestResult("coinFlips() működése hibás vagy nincs definiálva", false);
}

try {
  const countEvenFn = (window as any)["countEvenNumbers"];
  addTestResult("countEvenNumbers() definiálva van", typeof countEvenFn === "function");
  const evenCount = countEvenFn([2, 4, 5, 7, 8]);
  addTestResult("Páros számok száma: 3", evenCount === 3);
} catch (err) {
  addTestResult("countEvenNumbers() működése hibás vagy nincs definiálva", false);
}
