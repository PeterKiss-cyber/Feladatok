/*
* Ide hozza létre a createProduct(), coinFlips(), countEvenNumbers függvényeket.
*
*/
/*********** Tesztek *******************/
var taskResults = document.getElementById("task-results");
var testResults = document.getElementById("test-results");
var testCounter = 1;
function addTaskOutput(text) {
    var li = document.createElement("li");
    li.textContent = text;
    taskResults.appendChild(li);
}
function addTestResult(desc, passed) {
    var tr = document.createElement("tr");
    tr.innerHTML = "\n    <td>".concat(testCounter++, "</td>\n    <td>").concat(desc, "</td>\n    <td class=\"").concat(passed ? "success" : "fail", "\">").concat(passed ? "✅ OK" : "❌ HIBA", "</td>\n  ");
    testResults.appendChild(tr);
}
// Kiírás (védetten)
try {
    var createProductFn = window["createProduct"];
    if (typeof createProductFn === "function") {
        addTaskOutput("Product: " + JSON.stringify(createProductFn()));
    }
    else {
        throw new Error("createProduct nincs definiálva");
    }
}
catch (e) {
    addTaskOutput("Product: ❌ createProduct() nem működik");
}
try {
    var coinFlipsFn = window["coinFlips"];
    if (typeof coinFlipsFn === "function") {
        addTaskOutput("Coin flips (5): " + coinFlipsFn(5).join(", "));
    }
    else {
        throw new Error("coinFlips nincs definiálva");
    }
}
catch (e) {
    addTaskOutput("Coin flips: ❌ coinFlips() nem működik");
}
try {
    var countEvenFn = window["countEvenNumbers"];
    if (typeof countEvenFn === "function") {
        addTaskOutput("Even count: " + countEvenFn([1, 2, 4, 5, 8, 11]));
    }
    else {
        throw new Error("countEvenNumbers nincs definiálva");
    }
}
catch (e) {
    addTaskOutput("Even count: ❌ countEvenNumbers() nem működik");
}
// Tesztek (védetten)
try {
    var createProductFn = window["createProduct"];
    addTestResult("createProduct() definiálva van", typeof createProductFn === "function");
    var product = createProductFn();
    addTestResult("Product id szám", typeof product.id === "number");
    addTestResult("Product name szöveg", typeof product.name === "string");
    addTestResult("Product price szám", typeof product.price === "number");
    addTestResult("Product name tartalma tesztnév", product.name === "tesztnév");
}
catch (err) {
    addTestResult("createProduct() működése hibás vagy nincs definiálva", false);
}
try {
    var coinFlipsFn = window["coinFlips"];
    addTestResult("coinFlips() definiálva van", typeof coinFlipsFn === "function");
    var flips = coinFlipsFn(10);
    addTestResult("CoinFlips tömbbel tér vissza", Array.isArray(flips));
    addTestResult("CoinFlips hossza 10", flips.length === 10);
    addTestResult("CoinFlips értékei érvényesek", flips.every(function (f) { return f === "fej" || f === "írás"; }));
}
catch (err) {
    addTestResult("coinFlips() működése hibás vagy nincs definiálva", false);
}
try {
    var countEvenFn = window["countEvenNumbers"];
    addTestResult("countEvenNumbers() definiálva van", typeof countEvenFn === "function");
    var evenCount = countEvenFn([2, 4, 5, 7, 8]);
    addTestResult("Páros számok száma: 3", evenCount === 3);
}
catch (err) {
    addTestResult("countEvenNumbers() működése hibás vagy nincs definiálva", false);
}
