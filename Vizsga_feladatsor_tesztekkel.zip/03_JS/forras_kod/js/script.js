/* ===== 1. Páros-e? ===== */


/* ===== 2. Nagybetűk száma ===== */


/* ===== 3. Aktuális év ===== */





/* ----- Eredmények megjelenítése ----- */
window.addEventListener('DOMContentLoaded', () => {
  const ul = document.getElementById('results');
  const examples = [
    [`isEven(7) → ${isEven(7)}`],
    [`isEven(12) → ${isEven(12)}`],
    [`countUpperCaseLetters("Ez Egy Teszt") → ${countUpperCaseLetters("Ez Egy Teszt")}`],
    [`getCurrentYear() → ${getCurrentYear()}`],
  ];

  examples.forEach(([txt]) => {
    const li = document.createElement('li');
    li.textContent = txt;
    ul.appendChild(li);
  });
});
