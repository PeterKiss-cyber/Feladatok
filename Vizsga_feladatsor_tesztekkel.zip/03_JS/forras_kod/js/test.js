window.addEventListener('DOMContentLoaded', () => {
  const tbody  = document.querySelector('#test-results tbody');
  let   index  = 1;

  function addRow(desc, ok) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${index++}</td>
      <td>${desc}</td>
      <td style="color:${ok?'green':'red'}">${ok?'✅ OK':'❌ HIBA'}</td>`;
    tbody.appendChild(tr);
  }

  /* ===== Teszt 1 – isEven ===== */
  addRow('isEven(4) → true',  isEven(4)  === true);
  addRow('isEven(5) → false', isEven(5)  === false);
  addRow('isEven(0) → true',  isEven(0)  === true);

  /* ===== Teszt 2 – countUpperCaseLetters ===== */
  addRow('countUpperCaseLetters("ABCdef") → 3',
         countUpperCaseLetters('ABCdef') === 3);
  addRow('countUpperCaseLetters("noCaps") → 1',
         countUpperCaseLetters('noCaps') === 1);
  addRow('countUpperCaseLetters("") → 0',
         countUpperCaseLetters('') === 0);

  /* ===== Teszt 3 – getCurrentYear ===== */
  const thisYear = new Date().getFullYear();
  addRow(`getCurrentYear() → ${thisYear}`,
         getCurrentYear() === thisYear);
});
